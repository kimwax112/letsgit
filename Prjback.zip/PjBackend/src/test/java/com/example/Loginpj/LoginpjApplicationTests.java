package com.example.Loginpj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginpjApplicationTests {

	@Test
	void contextLoads() {
	}

}
